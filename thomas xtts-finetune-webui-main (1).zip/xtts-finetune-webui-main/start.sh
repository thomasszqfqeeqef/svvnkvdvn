#!/bin/bash

# Create a Python virtual environment
python -m venv venv
# Activate the virtual environment
source venv/bin/activate

python xtts_demo.py

